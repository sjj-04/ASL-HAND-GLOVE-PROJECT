"""Offline behavioral checks. Fixtures are synthetic, not ASL reference poses."""
import argparse
import copy
import json
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from free_mode import (BACK, FREE, LEARNING, GloveReader, TouchUI, free_image,
                       home_image, message_image, run_session)
from mcp3208 import FINGERS, SensorFrame
from recognition import (HoldGate, classify, load_profile, normalize, save_profile,
                         sensor_fault, validate_profile)
from touch_mapping import TARGETS, fit, hit, load_mapping, project, save_mapping


def profile():
    samples = {'A': [.1, .9, .9, .9, .9], 'B': [.9, .1, .1, .1, .1], 'C': [.5]*5}
    return {'version': 1, 'fingers': list(FINGERS), 'flat': [3000]*5, 'bent': [1000]*5,
            'references': {letter: [values[:], values[:], values[:]] for letter, values in samples.items()}}


class RecognitionTests(unittest.TestCase):
    def test_recorded_letters_and_small_noise(self):
        data = validate_profile(profile())
        for letter in ('A', 'B', 'C'):
            sample = data['references'][letter][0]
            self.assertEqual(classify(sample, data), letter)
            self.assertEqual(classify([x+.015 for x in sample], data), letter)

    def test_unknown_and_single_finger_error_are_rejected(self):
        data = profile()
        self.assertIsNone(classify([0, 0, 0, 1, 1], data))
        bad = data['references']['A'][0][:]
        bad[1] -= .3
        self.assertIsNone(classify(bad, data))

    def test_ambiguous_match_is_rejected(self):
        data = profile()
        data['references'] = {'A': [[0]*5]*3, 'B': [[.12]*5]*3, 'C': [[.8]*5]*3}
        validate_profile(data)
        self.assertIsNone(classify([.06]*5, data))

    def test_bad_profiles_and_indistinguishable_signs_rejected(self):
        for change in ('span', 'missing', 'duplicate', 'unstable', 'nan'):
            data = profile()
            if change == 'span': data['bent'][0] = 2900
            if change == 'missing': del data['references']['C']
            if change == 'duplicate': data['references']['B'] = copy.deepcopy(data['references']['A'])
            if change == 'unstable': data['references']['A'][1] = [.7]*5
            if change == 'nan': data['references']['C'][0][0] = float('nan')
            with self.subTest(change=change), self.assertRaises(ValueError):
                validate_profile(data)

    def test_normalization_decreasing_counts_and_faults(self):
        self.assertEqual(normalize([3000, 2000, 1000, 3500, 500], profile()), (0, .5, 1, 0, 1))
        for index in range(5):
            values = [2000]*5
            values[index] = 0
            self.assertIsNotNone(sensor_fault(values))
            with self.assertRaisesRegex(ValueError, 'SENSOR FAULT'):
                normalize(values, profile())
        self.assertIsNotNone(sensor_fault([float('nan')]*5))

    def test_profile_round_trip_and_failed_save_preserves_previous(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'glove.json'
            data = profile()
            save_profile(path, data)
            self.assertEqual(load_profile(path), data)
            invalid = copy.deepcopy(data)
            invalid['references']['B'] = copy.deepcopy(invalid['references']['A'])
            with self.assertRaises(ValueError): save_profile(path, invalid)
            self.assertEqual(load_profile(path), data)

    def test_hold_requires_continuity_and_resets_for_a_different_letter(self):
        gate = HoldGate(.5)
        self.assertIsNone(gate.update('A', 1))
        self.assertIsNone(gate.update('A', 1.25))
        self.assertEqual(gate.update('A', 1.51), 'A')
        self.assertIsNone(gate.update('B', 1.6))
        self.assertIsNone(gate.update(None, 1.7))
        self.assertIsNone(gate.update('B', 1.8))
        self.assertIsNone(gate.update('B', 2))
        self.assertEqual(gate.update('B', 2.31), 'B')

    def test_hold_cannot_accept_two_samples_separated_by_a_long_gap(self):
        gate = HoldGate(.5)
        self.assertIsNone(gate.update('A', 1))
        self.assertIsNone(gate.update('A', 5))
        self.assertIsNone(gate.update('A', 5.1))
        self.assertEqual(gate.update('A', 5.51), 'A')


class TouchTests(unittest.TestCase):
    def test_calibration_handles_swapped_reversed_axes(self):
        # Independent fixture: raw X falls as screen Y rises; raw Y follows screen X.
        raw = [(3500-y*30, 400+x*20) for x, y in TARGETS]
        mapping = fit(raw)
        for point, target in zip(raw, TARGETS):
            result = project(point, mapping)
            self.assertAlmostEqual(result[0], target[0], places=7)
            self.assertAlmostEqual(result[1], target[1], places=7)
        self.assertAlmostEqual(project((3500-40*30, 400+30*20), mapping)[0], 30)

    def test_bad_touch_captures_rejected(self):
        with self.assertRaises(ValueError): fit([(100,100)]*5)
        raw = [(x*20, y*30) for x, y in TARGETS]
        raw[-1] = (3000, 3000)
        with self.assertRaises(ValueError): fit(raw)

    def test_touch_file_round_trip_and_corruption(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'touch.json'
            mapping = fit([(x*20, y*30) for x,y in TARGETS])
            save_mapping(path, mapping)
            self.assertEqual(load_mapping(path), mapping)
            path.write_text('{"version":1,"coefficients":[[0,0,0],[0,0,0]]}')
            with self.assertRaises(ValueError): load_mapping(path)

    def test_menu_targets_are_separate_and_empty_gap_does_not_select(self):
        self.assertTrue(hit((64,25), LEARNING))
        self.assertFalse(hit((64,25), FREE))
        self.assertTrue(hit((64,50), FREE))
        self.assertFalse(hit((64,50), LEARNING))
        self.assertFalse(hit((64,38), LEARNING))
        self.assertFalse(hit((64,38), FREE))

    def test_application_routes_both_buttons_and_learning_returns_home(self):
        # Exercise the real session controller, bypassing physical touch sampling only.
        class Display:
            def __init__(self): self.frames=[]
            def show(self, frame): self.frames.append(frame.copy())
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            save_mapping(directory/'touch.json', fit([(x*20,y*30) for x,y in TARGETS]))
            save_profile(directory/'glove_profile.json', profile())
            args=argparse.Namespace(profile_dir=directory,touch_calibrate=False,glove_setup=False)
            display=Display()
            # Home Learning, Learning MENU, Home Free. End at the next home render.
            with patch.object(TouchUI,'wait_tap',side_effect=[0,0,1,KeyboardInterrupt]), \
                 patch('free_mode.free_screen', return_value='menu') as free:
                with self.assertRaises(KeyboardInterrupt):
                    run_session(object(),display,object(),args)
                free.assert_called_once()
            self.assertGreaterEqual(len(display.frames),4)
            self.assertEqual(display.frames[0].tobytes(),home_image().tobytes())
            self.assertNotEqual(display.frames[1].tobytes(),home_image().tobytes())

    def test_all_screens_fit_display(self):
        for frame in (home_image(),free_image('A','MATCH'),free_image(None,'FAULT INDEX'),
                      message_image('TEST',['one','two','three'],[(BACK,'MENU')])):
            self.assertEqual(frame.size,(128,64))
            self.assertEqual(frame.mode,'1')

    def test_fault_in_background_reader_clears_the_letter(self):
        import threading
        class ADC:
            def read_frame(self,samples=2): return SensorFrame(time.monotonic_ns(),(2000,0,2000,2000,2000))
        reader=GloveReader(ADC(),profile(),threading.RLock())
        reader.start()
        try:
            deadline=time.monotonic()+1
            while 'FAULT' not in reader.snapshot()[1] and time.monotonic()<deadline:
                time.sleep(.01)
            letter,status,_=reader.snapshot()
            self.assertIsNone(letter)
            self.assertEqual(status,'FAULT INDEX')
        finally: reader.stop()


if __name__=='__main__':
    unittest.main()
