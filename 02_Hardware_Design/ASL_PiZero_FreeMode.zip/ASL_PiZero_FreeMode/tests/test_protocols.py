"""Protocol and calibration checks with simulated peripherals, not bench tests."""

import sys
import tempfile
import unittest
from pathlib import Path

from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from asl_glove import display_pattern, live_image
from flex_calibration import bend_percent, load_calibration, save_calibration, validate_calibration
from mcp3208 import MCP3208, SensorFrame
from touch_panel import TouchPanel
from winstar_lcd import WinstarLCD, pack_image


class SimulatedLCD:
    BCM, OUT, HIGH, LOW = 11, 0, 1, 0

    def __init__(self):
        self.levels, self.writes, self.cleaned = {}, [], None
        self.ram = [[[0xA5] * 64 for _ in range(8)] for _ in range(2)]
        self.page, self.column = [0, 0], [0, 0]
        self.on, self.start_line = [False, False], [None, None]

    def setmode(self, mode):
        assert mode == self.BCM

    def setup(self, pin, mode, initial):
        self.levels[pin] = initial

    def output(self, pins, values):
        if isinstance(pins, (tuple, list)):
            for pin, value in zip(pins, values):
                self.output(pin, value)
            return
        old = self.levels.get(pins, 0)
        self.levels[pins] = values
        if pins == WinstarLCD.E and old == 1 and values == 0:
            selected = [i for i, cs in enumerate(WinstarLCD.CS) if self.levels[cs] == 0]
            assert len(selected) == 1, "Exactly one active-low chip select per write"
            half = selected[0]
            byte = sum(self.levels[pin] << bit for bit, pin in enumerate(WinstarLCD.DATA))
            is_data = self.levels[WinstarLCD.DI]
            self.writes.append((half, byte, is_data))
            if is_data:
                self.ram[half][self.page[half]][self.column[half]] = byte
                self.column[half] = (self.column[half] + 1) % 64
            elif byte in (0x3E, 0x3F):
                self.on[half] = byte == 0x3F
            elif 0x40 <= byte <= 0x7F:
                self.column[half] = byte & 63
            elif 0xB8 <= byte <= 0xBF:
                self.page[half] = byte & 7
            elif 0xC0 <= byte <= 0xFF:
                self.start_line[half] = byte & 63
            else:
                raise AssertionError("Unsupported controller command: {}".format(byte))

    def cleanup(self, pins):
        self.cleaned = tuple(pins)


class SimulatedSPI:
    def __init__(self):
        self.calls, self.closed = [], False
        self.values = [n * 501 for n in range(8)]

    def open(self, bus, device):
        assert (bus, device) == (0, 0)

    def xfer2(self, tx):
        assert len(tx) == 3 and tx[0] in (6, 7)
        assert tx[1] & 0x3F == 0 and tx[2] == 0
        channel = ((tx[0] & 1) << 2) | (tx[1] >> 6)
        self.calls.append(channel)
        value = self.values[channel]
        return [0xFF, 0xF0 | (value >> 8), value & 255]

    def close(self):
        self.closed = True


class SimulatedI2C:
    def __init__(self, pressed=True):
        self.regs, self.writes, self.states = {}, [], []
        self.is_pressed, self.closed = pressed, False

    def write_byte_data(self, address, reg, value):
        assert address == 0x20
        self.regs[reg] = value
        self.writes.append((reg, value))
        if reg == TouchPanel.IODIRA and value != 0xFF:
            self.states.append((value, self.regs[TouchPanel.OLATA], self.regs[TouchPanel.GPPUA]))

    def read_byte_data(self, address, reg):
        assert (address, reg) == (0x20, TouchPanel.GPIOA)
        return 0 if self.is_pressed else 1

    def close(self):
        self.closed = True


class ProtocolTests(unittest.TestCase):
    def test_gpio_assignments_match_the_assembly_schematic(self):
        # Independent transcription: LCD pins 1, 2, 6, 8, 17 and 9..16.
        self.assertEqual(WinstarLCD.CS, (17, 27))
        self.assertEqual((WinstarLCD.DI, WinstarLCD.E, WinstarLCD.RESET), (22, 23, 24))
        self.assertEqual(WinstarLCD.DATA, (5, 6, 12, 13, 16, 19, 20, 21))
        gpio = SimulatedLCD()
        with WinstarLCD(gpio, delay_us=lambda _: None, sleep=lambda _: None):
            self.assertEqual(set(gpio.levels),
                             {5, 6, 12, 13, 16, 17, 19, 20, 21, 22, 23, 24, 27})

    def test_all_eight_data_bits_and_erasure_on_both_halves(self):
        gpio = SimulatedLCD()
        with WinstarLCD(gpio, delay_us=lambda _: None, sleep=lambda _: None) as lcd:
            for bit in range(8):
                image = Image.new("1", (128, 64))
                for column in (0, 63, 64, 127):
                    image.putpixel((column, 56 + bit), 1)
                lcd.show(image)
                for half in range(2):
                    self.assertEqual(gpio.ram[half][7][0], 1 << bit)
                    self.assertEqual(gpio.ram[half][7][63], 1 << bit)
            lcd.show(Image.new("1", (128, 64)))
            self.assertTrue(all(value == 0 for half in gpio.ram
                                for page in half for value in page))

    def test_malformed_calibration_is_rejected_as_a_value_error(self):
        for root in ([], None, "invalid", 42):
            with self.subTest(root=root), self.assertRaises(ValueError):
                validate_calibration(root)
        for value in (True, False, float("nan"), float("inf"), -1, 4096, "2000"):
            calibration = {"version": 1,
                           "fingers": ["Thumb", "Index", "Middle", "Ring", "Little"],
                           "flat": [3000] * 5, "bent": [1000] * 5}
            calibration["flat"][2] = value
            with self.subTest(value=value), self.assertRaises(ValueError):
                validate_calibration(calibration)

    def test_pixel_orientation_and_both_controller_edges(self):
        image = Image.new("1", (128, 64))
        for point in ((0, 0), (63, 7), (64, 8), (127, 63)):
            image.putpixel(point, 1)
        packed = pack_image(image)
        self.assertEqual(len(packed), 1024)
        self.assertEqual({i: byte for i, byte in enumerate(packed) if byte},
                         {0: 1, 63: 128, 192: 1, 1023: 128})
        gpio = SimulatedLCD()
        with WinstarLCD(gpio, delay_us=lambda _: None, sleep=lambda _: None) as lcd:
            self.assertEqual(gpio.on, [True, True])
            self.assertEqual(gpio.start_line, [0, 0])
            self.assertTrue(all(value == 0 for half in gpio.ram for page in half for value in page))
            lcd.show(image)
            self.assertEqual(gpio.ram[0][0][0], 1)
            self.assertEqual(gpio.ram[0][0][63], 128)
            self.assertEqual(gpio.ram[1][1][0], 1)
            self.assertEqual(gpio.ram[1][7][63], 128)
            before = len(gpio.writes)
            lcd.show(image)
            self.assertEqual(len(gpio.writes), before, "Unchanged frame must produce no writes")
        self.assertEqual(gpio.on, [False, False])
        self.assertFalse(set(gpio.cleaned) & {2, 3, 8, 9, 10, 11})

    def test_spi_all_channels_and_result_mask(self):
        spi = SimulatedSPI()
        with MCP3208(spi) as adc:
            for code in (0, 1, 2048, 4095):
                spi.values = [code] * 8
                self.assertEqual([adc.read_channel(ch) for ch in range(8)], [code] * 8)
            self.assertEqual(spi.mode, 0)
            self.assertEqual(spi.max_speed_hz, 20000)
            self.assertFalse(spi.cshigh)
            with self.assertRaises(ValueError):
                adc.read_channel(8)
        self.assertTrue(spi.closed)

    def test_read_frame_retains_finger_order_and_monotonic_timestamp(self):
        spi = SimulatedSPI()
        with MCP3208(spi) as adc:
            frame = adc.read_frame(samples=2)
        self.assertEqual(frame.counts, (0, 501, 1002, 1503, 2004))
        self.assertGreater(frame.timestamp_ns, 0)
        self.assertEqual(spi.calls, [0] * 3 + [1] * 3 + [2] * 3 + [3] * 3 + [4] * 3)

    def test_touch_axis_drive_and_cross_axis_sense(self):
        bus, spi = SimulatedI2C(), SimulatedSPI()
        with MCP3208(spi) as adc, TouchPanel(adc, bus=bus, sleep=lambda _: None) as touch:
            self.assertEqual(touch.read_raw(), (3006, 2505))
            self.assertEqual(bus.states, [(0xF7, 0, 1), (0xFC, 1, 0),
                                          (0xF3, 4, 0), (0xF7, 0, 1)])
            self.assertEqual(spi.calls, [6] * 5 + [5] * 5)
            self.assertEqual(bus.regs[TouchPanel.IODIRA], 0xFF)
            self.assertEqual(bus.regs[TouchPanel.GPPUA], 0)
            for index, (reg, value) in enumerate(bus.writes):
                if reg == TouchPanel.OLATA:
                    self.assertEqual(bus.writes[index - 2], (TouchPanel.IODIRA, 0xFF))
        self.assertTrue(bus.closed)

    def test_no_touch_does_not_sample_floating_adc(self):
        bus, spi = SimulatedI2C(pressed=False), SimulatedSPI()
        with MCP3208(spi) as adc, TouchPanel(adc, bus=bus, sleep=lambda _: None) as touch:
            self.assertIsNone(touch.read_raw())
            self.assertEqual(spi.calls, [])

    def test_calibration_roundtrip_decreasing_counts_and_clamps(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "calibration.json"
            save_calibration(path, [3000] * 5, [1000] * 5)
            calibration = load_calibration(path)
            self.assertEqual(bend_percent((3000, 2000, 1000, 4000, 0), calibration),
                             (0, 50, 100, 0, 100))
            with self.assertRaises(ValueError):
                save_calibration(path, [1000] * 5, [1010] * 5)
            self.assertEqual(load_calibration(path), calibration)

    def test_images_are_valid_complete_frames(self):
        for image in (display_pattern(), live_image(SensorFrame(1, (0, 1000, 2000, 3000, 4095)))):
            self.assertEqual(image.size, (128, 64))
            self.assertEqual(image.mode, "1")
            self.assertGreater(sum(bool(byte) for byte in pack_image(image)), 100)


if __name__ == "__main__":
    unittest.main()
